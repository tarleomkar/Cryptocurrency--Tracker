# B) Write Python GUI program to accept a number n and check whether it is Prime, 
# Perfect or Armstrong number or not. Specify three radio buttons. 

from tkinter import *

def prime():
    n=2
    if(n==1 or n==0 or (n%2==0 and n>2)):
        selection="not  prime number"
        label.config(text=selection)
    else:
        for i in range(3,int(n**(1/2)+1)):
            if n%i==0:
                selection="not  prime number"
                label.config(text=selection)
        selection=" prime number "
        label.config(text=selection)


def perfect():
    n=6
    sum=0
    for x in range(1,n):
        if n%x==0:
            sum+=x
    if sum==n:
        selection=" perfect number"
        label.config(text=selection)
    else:
        selection="not  perfect number"
        label.config(text=selection)
        
def armstrong():
    n=153
    sum=0
    temp=n
    while temp>0: 
        result=temp%10
        sum+=result**3
        temp//=10
    if sum== n:
        selection=" armstrong number"
        label.config(text=selection)
    else:
        selection="not  armstrong number"
        label.config(text=selection)


top=Tk()

top.geometry("500x300")

radio=IntVar()

R1=Radiobutton(top,text="prime number",variabl=radio,value=1,command=prime)
R1.pack(anchor = W)
R2=Radiobutton(top,text="perfect number",variabl=radio,value=2,command=perfect)
R2.pack(anchor = W)
R3=Radiobutton(top,text="armstrong number",variabl=radio,value=3,command=armstrong)
R3.pack(anchor = W)

label=Label()
label.pack(anchor= W)

top.mainloop()
