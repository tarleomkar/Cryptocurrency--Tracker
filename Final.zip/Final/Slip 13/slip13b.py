# B) Write a program to implement the concept of queue using list

q=[]

def enqueue():
    element=int(input("enter the element: "))
    q.append(element)
    print(element,"element is added succedfully: ")
def dequeue():
    if not q:
        print("queue is empty :")
    else:
        ele=q.pop(0)
def display():
    print(q)

def menu():
    size=int(input("enter he size of queue: "))

    while True:
        choice=int(input("select an operation: \n1.add\n2.delete\n3.display\n4.quit\n enter an operation"))

        if choice==1:
            if len(q)==size:
                print("queue is full :")
            else:
                enqueue()
        elif choice ==2:
            dequeue()
        elif choice==3:
            display()
        elif choice==4:
            break
        else:
            print("enter the a valid choice: ")
menu()

# Output
# enter he size of queue: 3
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation1
# enter the element: 1
# 1 element is added succedfully:
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation1
# enter the element: 2
# 2 element is added succedfully:
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation1
# enter the element: 2
# 2 element is added succedfully:
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation3
# [1, 2, 2]
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation2
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation2
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation3
# [2]
# select an operation:
# 1.add
# 2.delete
# 3.display
# 4.quit
#  enter an operation4