// A) Write a java program to accept ‘n’ integers from the user & store them in an 
// ArrayList collection. Display the elements of ArrayList collection in reverse order.

import java.util.*;

class slip13a
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("how many elements you want: ");
		int n=sc.nextInt();
		ArrayList list=new ArrayList();
		System.out.println("enter the element of array collection: ");
		for(int i=0;i<n;i++)
		{
			String ele= sc.next();
			list.add(ele);
		}
		System.out.println("original array list "+list);
		Collections.reverse(list);
		System.out.println("reversed arry list are"+list);
	}
}

// Output
// how many elements you want: 
// 3
// enter the element of array collection:
// 3
// 2
// 1
// original array list [3, 2, 1]
// reversed arry list are[1, 2, 3]