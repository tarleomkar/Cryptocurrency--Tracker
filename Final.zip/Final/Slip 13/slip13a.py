# A) Write a Python program to input a positive integer. Display correct message for 
# correct and incorrect input. (Use Exception Handling)

while True:
    try:
        num = int(input("Enter a positive integer: "))
        if num < 0:
            raise ValueError
    except ValueError:
        print("Incorrect input. Please enter a positive integer.")
        continue
    else:
        print("Correct input.")
        break

# Output
# Enter a positive integer: -1
# Incorrect input. Please enter a positive integer.