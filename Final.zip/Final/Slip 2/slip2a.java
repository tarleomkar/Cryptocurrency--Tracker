// A) Write a java program to display all the vowels from a given string.

import java.util.*;
class slip2a
{
	public static void main(String a[])
	{
		String str;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string:");
		str=sc.nextLine();
		String str1=str.toLowerCase();
		System.out.println("string after coversion is :"+str);
		for(int i=0;i<str.length();i++)
		{
			char c=str1.charAt(i);
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			{
				System.out.println(c);
			}
		}
	}
}

// Output
// a
// a