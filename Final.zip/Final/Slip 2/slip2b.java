// B) Design a screen in Java to handle the Mouse Events such as MOUSE_MOVED and 
// MOUSE_CLICK and display the position of the Mouse_Click in a TextField.

import java.awt.*;
import java.awt.event.*;
 class SlipFrame extends Frame
{
	TextField t,t1;
	Label l,l1;
	int x,y;
	Panel p;
	SlipFrame(String title)
 {
	super(title);
	setLayout(new FlowLayout());
	p=new Panel();
	p.setLayout(new GridLayout(2,2,5,5));
	t=new TextField(20);
	l=new Label("co-ordinates of mouse clicked");
	l1=new Label("co-ordinates of mouse moved");
	t1=new TextField(20);
	p.add(l);
	p.add(t);
	p.add(l1);
	p.add(t1);
	add(p);

	addMouseListener(new MyClick());
	addMouseMotionListener(new MyMovement());

	setSize(500,500);
	setVisible(true);

 }
 	class MyClick extends MouseAdapter
 	{
		public void mouseClicked(MouseEvent m)
		{
			x=m.getX();
			y=m.getY();
			t.setText("X ="+x+" "+"Y ="+y);
		}
	}
	class  MyMovement extends MouseMotionAdapter
	{
		public void mouseMoved(MouseEvent h)
		{
			x=h.getX();
			y=h.getY();
			t1.setText("X ="+x+" "+"Y ="+y);

		}
	}
}
  class slip2b
  {
	  public static void main(String args[])
	  {
		SlipFrame f=new SlipFrame("slip2b");
	  }
  }