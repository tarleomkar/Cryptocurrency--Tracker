# B) Write Python GUI program to create a digital clock with Tkinter to display the time.

from tkinter import *
from tkinter.ttk import *
from time import strftime

window=Tk()
window.resizable(width=False,height=False)
window.title("Digital clock")
def time():
    string=strftime('%H:%M:%S %p')
    lbl.config(text=string)
    lbl.after(1000,time)
lbl=Label(window,font=('Arial',30,'bold'),background='black',foreground='white')
lbl.pack(anchor='center')
time()
mainloop()
