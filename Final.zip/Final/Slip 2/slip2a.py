# A) Write a Python function that accepts a string and calculate the number of upper case 
# letters and lower case letters. 
# Sample String: 'The quick Brown Fox'
# Expected Output: 
# No. of Upper case characters: 3
# No. of Lower case characters: 13

def sample_string(s):
    d={"UPPER_CASE":0, "LOWER_CASE":0}

    for c in s:
        if c.isupper():
            d["UPPER_CASE"]+=1
        elif c.islower():
            d["LOWER_CASE"]+=1
        else:
            pass
    print("no of uppercase letter:",d["UPPER_CASE"])
    print("no of lowercase letter:",d["LOWER_CASE"])
        
sample_string("The quick Brown Fox")   

# Output
# no of uppercase letter: 3
# no of lowercase letter: 13