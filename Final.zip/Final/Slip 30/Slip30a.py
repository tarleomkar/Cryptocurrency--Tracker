string = input("Please enter your own String : ")
char = input("Please enter your own Character : ")

count = 0
for i in range(len(string)):
    if(string[i] == char):
        count = count + 1

print("The total Number of Times ", char, " has Occurred = " , count)

# Output
# Please enter your own String : satya  
# Please enter your own Character : s
# The total Number of Times  s  has Occurred =  1