# B) Python Program to Create a Class in which One Method Accepts a String from the 
# User and Another method Prints it. Define a class named Country which has a method 
# called print Nationality. Define subclass named state from Country which has a mehtod 
# called printState. Write a method to print state, country and nationality.

class Country: 
    def __init__(self, nationality): 
        self.nationality = nationality 
  
    def printNationality(self): 
        print("Nationality: " + self.nationality) 
  
# Subclass 
class State(Country): 
    def __init__(self, state, nationality): 
        Country.__init__(self, nationality) 
        self.state = state 
  
    def printState(self): 
        print("State: " + self.state) 
  
# Driver code 
obj = State("Maharashtra", "Indian") 
obj.printState() 
obj.printNationality() 

# Output
# State: Maharashtra
# Nationality: Indian