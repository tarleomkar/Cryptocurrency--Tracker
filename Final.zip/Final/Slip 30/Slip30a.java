// A) Write a java program to accept a number from a user, if it is zero then throw user 
// defined Exception “Number is Zero”. If it is non-numeric then generate an error 
// “Number is Invalid” otherwise check whether it is palindrome or not.

import java.io.*;

class Numberiszero extends Exception{}

class Slip30a{

    public static void main(String args[])
    {
        int r,sum=0,temp; 
        int n;
        DataInputStream dr = new DataInputStream(System.in);
        try
        {
            System.out.print("Enter Number : ");
            n = Integer.parseInt(dr.readLine());
            if(n==0)
            {
                throw new Numberiszero();
            }
            else
            {
                temp=n; 
                while(n>0)
                { 
                    r=n%10;
                    sum=(sum*10)+r;
                    n=n/10; 
                } 
                if(temp==sum)
                {
                    System.out.println("Palindrome Number "); 
                }
                else
                {
                    System.out.println("Not Palindrome");
                }
            }
        }catch(Numberiszero nz) 
        {
            System.out.println("Number is Zero");
        }
        catch (NumberFormatException e)
        {
            System.out.println("Number is Invalid");
        }
        catch (Exception e){}
    }
}

// Output
// Enter Number : 22
// Palindrome Number