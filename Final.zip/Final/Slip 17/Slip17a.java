// A) Write a java Program to accept ‘n’ no’s through command line and store only 
// armstrong no’s into the array and display that array. 

public class Slip17a
{
    public static void main(String[] args) 
    {
        int num, i, r, sum = 0, temp, count = 0;
        num = args.length;
        // Creating array
        int a[] = new int[num];
        int b[] = new int[10];

        for(i=0;i<num;i++)
        {
            a[i] = Integer.parseInt(args[i]);
            sum = 0;
            temp = a[i];
            // Checking armstrong number
            while(a[i]!=0)
            {
                r = a[i] % 10;
                sum = sum + r * r * r;
                a[i] = a[i] / 10;
            }

            if(temp == sum)
            {
                b[count] = temp;
                count++;
            }
        }
        for(i=0;i<count;i++)
        {
            System.out.print(b[i]+" ");
        }
    }
}

// Output
// D:\TYBBACA OMKAR\Slips\Slip 17>java Slip17a 153 253 451 432
// 153