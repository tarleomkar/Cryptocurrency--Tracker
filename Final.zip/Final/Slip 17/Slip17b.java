// B) Define a class Product (pid, pname, price, qty). Write a function to accept the product 
//  details, display it and calculate total amount. (use array of Objects) 

import java.util.*;

class Product
{
    String pname;
    int pid, qty;
    float price, total;

    void accept()
    {
        Scanner sc = new Scanner(System.in);
        try{
            System.out.println("Enter product name: ");
            pname = sc.next();
            System.out.println("Enter product id: ");
            pid = sc.nextInt();
            System.out.println("Enter product qty: ");
            qty = sc.nextInt();
            System.out.println("Enter product price: ");
            price = sc.nextFloat();
        }catch(Exception e){}
    }

    void display()
    {
        total = qty * price;
        System.out.println("Pid : "+ pid+"\n Product Name : "+pname+"\n Quantity : "+qty+"\n Price"+price+"\n Total Amount: "+total);
    }
}

class Slip17b
{
    public static void main(String[] args) 
    {
        int n;
        float t = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter how many product you want: ");
        n=sc.nextInt();

        Product p1[] = new Product[n];
        for(int i=0;i<n;i++)
        {
            p1[i] = new Product();
            p1[i].accept();
        }
        for(int i=0;i<n;i++)
        {
            p1[i].display();
        }
        for(int i=0;i<n;i++)
        {
            t = t + p1[i].total;
            System.out.println("Total Amount: "+t);
        }
    }
}

// Output
// Enter how many product you want: 3
// Enter product name:
// apple
// Enter product id:
// 101
// Enter product qty:
// 3
// Enter product price:
// 5000
// Enter product name:
// Samsung
// Enter product id:
// 102
// Enter product qty:
// 3
// Enter product price:
// 6000
// Enter product name:
// Lava
// Enter product id:
// 103
// Enter product qty:
// 3
// Enter product price:
// 7000
// Pid : 101
//  Product Name : apple
//  Quantity : 3
//  Price5000.0
//  Total Amount15000.0
// Pid : 102
//  Product Name : Samsung
//  Quantity : 3
//  Price6000.0
//  Total Amount18000.0
// Pid : 103
//  Product Name : Lava
//  Quantity : 3
//  Price7000.0
//  Total Amount: 21000.0
// Total Amount: 15000.0
// Total Amount: 33000.0
// Total Amount: 54000.0