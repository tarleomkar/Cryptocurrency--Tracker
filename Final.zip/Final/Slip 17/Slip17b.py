# B) Define a class Date (Day, Month, Year) with functions to accept and display it. 
# Accept date from user. Throw user defined exception “invalid Date Exception” if the 
# date is invalid.

from datetime import datetime,date

class Date:
    # Creating global variable
    date_input = ""

    def accept(self):
        self.date_input = input("Enter date in format (dd/mm/yyyy): ")

    def display(self):
        try:
            valid_date = datetime.strptime(self.date_input,'%d/%m/%Y').date()

            if valid_date:
                print(valid_date)
        except ValueError:
            print("Invalid Date")

obj = Date()
obj.accept()
obj.display()

# Output
# Enter date in format (dd/mm/yyyy): 06/01/
# 2023
# 2023-01-06