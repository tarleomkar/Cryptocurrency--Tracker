# A) Write Python GUI program that takes input string and change letter to upper case 
# when a button is pressed.

import tkinter as tk

window = tk.Tk()
window.title("Case Changer")
window.geometry("200x100")

def upper_case():
    result = entry.get()
    lbl.config(text=result.upper())       

entry = tk.Entry(window)
entry.pack()

b1 = tk.Button(window,text="Upper case",command = upper_case)
b1.pack()

lbl = tk.Label(window,text="")
lbl.pack()



window.mainloop()
