// A) Write a ‘java’ program to display characters from ‘A’ to ‘Z’
public class slip1a 
{
    public static void main(String[] args) 
    {
       char charatcers;
       System.out.println("Displaying Alphabets from A to Z ");
       for(charatcers= 'A'; charatcers <= 'Z'; ++ charatcers)
       System.out.print(charatcers+ " ");
    }
}

// Displaying Alphabets from A to Z 
// A B C D E F G H I J K L M N O P Q R S T U V W X Y Z 
