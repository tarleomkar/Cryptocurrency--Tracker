# A) Write a Python program to accept n numbers in list and remove duplicates from a 
# list.

my_list = [] 
n = int(input("Enter number of elements in list: ")) 
  
for i in range(0, n): 
    ele = int(input()) 
    my_list.append(ele) 
      
print("Original List: ", my_list) 

final_list = [] 
for num in my_list: 
    if num not in final_list: 
        final_list.append(num) 
          
print("List after removing duplicates: ", final_list)

# Output
# Enter number of elements in list: 5
# 1
# 2
# 3
# 4
# 1
# Original List:  [1, 2, 3, 4, 1]
# List after removing duplicates:  [1, 2, 3, 4]