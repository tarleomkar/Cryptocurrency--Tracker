# B) Write Python GUI program to take accept your birthdate and output your age when a 
# button is pressed. 

import tkinter as tk
from datetime import datetime

def calculate_age():
    # Get the birthdate from the user input
    birthdate = entry.get()
    # Convert the birthdate to a datetime object
    birthdate = datetime.strptime(birthdate, "%Y-%m-%d")
    # Calculate the age by subtracting the birthdate from the current date
    age = (datetime.now() - birthdate).days / 365
    # Output the age to the user
    output_label.config(text=f"Your age is: {age:.2f} years")

root = tk.Tk()
root.title("Age Calculator")

# Create a label for the birthdate input
birthdate_label = tk.Label(root, text="Enter your birthdate (YYYY-MM-DD):")
birthdate_label.pack()

# Create a text entry for the birthdate input
entry = tk.Entry(root)
entry.pack()

# Create a button to calculate the age
calculate_button = tk.Button(root, text="Calculate Age", command=calculate_age)
calculate_button.pack()

# Create a label to output the age
output_label = tk.Label(root, text="")
output_label.pack()

root.mainloop()
