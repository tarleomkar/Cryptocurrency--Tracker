public class Cubes 
{
    public void cubeSeries(int n)
    {
        for(int i = 1; i <= n; i++)
        {
            int res = (i * i * i);
            System.out.println(res+" ");
            
        }
    }
}
