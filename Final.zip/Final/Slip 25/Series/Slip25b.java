// B) Create a package named Series having three different classes to print series:
// i. Fibonacci series
// ii. Cube of numbers
// iii. Square of numbers
// Write a java program to generate ‘n’ terms of the above series.

import java.util.*;
import Series.*;

class Slip25b
{
    public static void main(String[] args) 
    {
        int n1, n2, n3;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter how many fibonnacci series you want: ");
        n1=sc.nextInt();
        System.out.println("Enter how many cube series you want: ");
        n2=sc.nextInt();
        System.out.println("Enter how many square series you want: ");
        n3=sc.nextInt();

        System.out.println("\n---------- Fibonnacci Series--------\n\n");
        Fib f = new Fib();
        f.fibSeries(n1);
        System.out.println("\n---------- Cube Series--------\n\n");
        Cubes c = new Cubes();
        c.cubeSeries(n2);
        System.out.println("\n---------- Square Series--------\n\n");
        Square s = new Square();
        s.squareSeries(n3);
    }
}