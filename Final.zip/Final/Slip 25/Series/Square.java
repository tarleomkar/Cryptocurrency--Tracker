public class Square 
{
    public void squareSeries(int n)    
    {
        for(int i = 1; i <= n; i++)
        {
            int res = (i * i);
            System.out.println(res+" ");
        }
    }
}
