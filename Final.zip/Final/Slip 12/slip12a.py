# A) Write a Python GUI program to create a label and change the label font style (font 
# name, bold, size) using tkinter module. 

import tkinter as tk

window = tk.Tk()
window.title("Font Changer")

label = tk.Label(window,text = "slip 12",font = ("Arial",50))

label.pack()

window.mainloop()