// A) Write a java program to display each String in reverse order from a String array
class slip12a
{
    public static void main(String[] args) 
    {
            String arr[] = {"Omkar","Mamu","Pritesh","Omi"};
            for(int i = arr.length - 1;i >= 0; i--)
            {
                System.out.println(arr[i]+' ');
            }
    }
}

// Output
// Omi 
// Pritesh
// Mamu
// Omkar