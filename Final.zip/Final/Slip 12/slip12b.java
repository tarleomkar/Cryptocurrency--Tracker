// B) Write a java program to display multiplication table of a given number into the List 
// box by clicking on button.

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class slip12b extends Applet implements ActionListener
{
    Button b1 = new Button("Show");   

    List Multiply = new List();

    String str = "";

    public void init()
    {
        Multiply.add("1");
        Multiply.add("2");
        Multiply.add("3");
        Multiply.add("4");
        Multiply.add("5");
        Multiply.add("6");
        Multiply.add("7");
        Multiply.add("8");
        Multiply.add("9");
        Multiply.add("10");

        add(Multiply);
        add(b1);

        b1.addActionListener(this);
    }

    public void paint(Graphics g)
    {
        int count = 100;

        int num = Integer.parseInt(Multiply.getSelectedItem());

        for(int i = 1; i <= 10; i++)
        {
            int a = num * i;

            g.drawString(num + " * " + i + " = " + a,100,count);

            count = count + 20;
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        repaint();
    }
}

