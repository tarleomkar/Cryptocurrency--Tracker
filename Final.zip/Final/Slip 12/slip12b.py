# B) Write a python program to count repeated characters in a string.
# Sample string: 'thequickbrownfoxjumpsoverthelazydog'
# Expected output: o-4, e-3, u-2, h-2, r-2, t-2

import collections 

String = 'thequickbrownfoxjumpsoverthelazydog'

d = collections.defaultdict(int)

for x in String:
    d[x] += 1

for i in sorted(d,key=d.get,reverse=True):
    if d[i] > 1:
        print('%s %d' % (i,d[i]))

# Output
# o 4
# e 3
# t 2
# h 2
# u 2
# r 2