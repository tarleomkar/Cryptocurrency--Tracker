# A) Write a Python GUI program to accept a number form user and display its 
# multiplication table on button click. 

from tkinter import *

Window = Tk()
Window.title("Multiplication Tabel")

def multiply():
    n = int(entry.get())
    str1 = "Tabel of " + str(n) + "\n----------------------\n"
    for x in range(1,11):
        str1 = str1 + " " + str(n) + " x " + str(x) + " = " + str(n*x) + "\n"
    output_lbl.config(text = str1,justify=LEFT)

lbl = Label(text= "Enter a number",font=('Arial',12))

output_lbl = Label(font=('Arial',12))

entry = Entry(font=('Arial',12),width=5)

btn = Button(text = "Click to Multiply",font=('Arial',12),command = multiply)

lbl.grid(row=0,column=0,padx=10,pady=10)

entry.grid(row=0,column=1,padx=10,pady=10,ipady=10)

btn.grid(row=0,column=2,padx=10,pady=10)

output_lbl.grid(row=1,column=0,columnspan=3,padx=10,pady=10)

Window.mainloop()