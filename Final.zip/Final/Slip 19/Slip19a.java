// A) Write a Java program to display Fibonacci series using function. 

import java.util.*;

class Slip19a
{
    static void fibonacci()
    {
        int i, a, b, c, n;
        Scanner sc = new Scanner(System.in);
        try{
            System.out.println("Enter number: ");
            n=sc.nextInt();
            a = b = 1;
            System.out.println("You fibonacci series are: "+ a + " " + b);
            for(i=1;i<=n;i++)
            {
                c = a + b;
                System.out.print(" "+c);
                a = b;
                b = c;
            }
        }catch(Exception e){}
    }
    public static void main(String[] args) 
    {
    fibonacci();    
    }
}

// Output
// Enter number: 
// 6
// You fibonacci series are: 1 1
//  2 3 5 8 13 21