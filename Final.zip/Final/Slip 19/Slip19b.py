# B) Define a class named Shape and its subclass(Square/ Circle). The subclass has an 
# init function which takes an argument (Lenght/redious). Both classes should have 
# methods to calculate area and volume of a given shape.

class Shape(object):
    def __init__(self):
        pass
         
    def area(self):
        return 0

    def volume(self):
        return 0

class Square(Shape):
    def __init__(self,l):
        Shape.__init__(self)
        self.length = l

    def area(self):
        return self.length*self.length

    def volume(self):
        return self.length*self.length*self.length

asquare = Square(int(input("Enter sides: ")))
print(asquare.area())
print(asquare.volume())

# Output
# Enter sides: 5
# 25
# 125