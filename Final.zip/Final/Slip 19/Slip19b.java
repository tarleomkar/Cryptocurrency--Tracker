// B) Create an Applet that displays the x and y position of the cursor movement 
// using Mouse and Keyboard. (Use appropriate listener)

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Slip19b extends Applet implements MouseMotionListener, KeyListener {
    private int x, y;

    public void init() {
        addMouseMotionListener(this);
        addKeyListener(this);
        setFocusable(true);
    }

    public void paint(Graphics g) {
        g.drawString("X: " + x + " Y: " + y, x, y);
    }

    public void mouseMoved(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        repaint();
    }

    public void mouseDragged(MouseEvent e) {
        // not implemented
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            System.exit(0);
        }
    }

    public void keyReleased(KeyEvent e) {
        // not implemented
    }

    public void keyTyped(KeyEvent e) {
        // not implemented
    }
}
