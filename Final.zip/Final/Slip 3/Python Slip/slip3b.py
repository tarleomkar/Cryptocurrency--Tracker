# B) Write a python script to define a class student having members roll no, name, age, 
# gender. Create a subclass called Test with member marks of 3 subjects. Create three 
# objects of the Test class and display all the details of the student with total marks.

class Student:
    def __init__(self, roll_no, name, age, gender):
        self.roll_no = roll_no
        self.name = name
        self.age = age
        self.gender = gender

class Test(Student):
    def __init__(self, roll_no, name, age, gender, marks1, marks2, marks3):
        super().__init__(roll_no, name, age, gender)
        self.marks1 = marks1
        self.marks2 = marks2
        self.marks3 = marks3
    
    def total_marks(self):
        return self.marks1 + self.marks2 + self.marks3

# Create three objects of the Test class
student1 = Test(1, "John Doe", 20, "Male", 75, 80, 90)
student2 = Test(2, "Jane Smith", 22, "Female", 85, 90, 95)
student3 = Test(3, "Bob Johnson", 21, "Male", 80, 85, 88)

# Display all the details of the students with total marks
for student in [student1, student2, student3]:
    print(f'Roll No: {student.roll_no}')
    print(f'Name: {student.name}')
    print(f'Age: {student.age}')
    print(f'Gender: {student.gender}')
    print(f'Marks1: {student.marks1}')
    print(f'Marks2: {student.marks2}')
    print(f'Marks3: {student.marks3}')
    print(f'Total Marks: {student.total_marks()}')
    print("\n")

# Output
# Roll No: 1
# Name: John Doe
# Age: 20
# Gender: Male
# Marks1: 75
# Marks2: 80
# Marks3: 90
# Total Marks: 245


# Roll No: 2
# Name: Jane Smith
# Age: 22
# Gender: Female
# Marks1: 85
# Marks2: 90
# Marks3: 95
# Total Marks: 270


# Roll No: 3
# Name: Bob Johnson
# Age: 21
# Gender: Male
# Marks1: 80
# Marks2: 85
# Marks3: 88
# Total Marks: 253