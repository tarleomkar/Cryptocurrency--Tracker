# A) Write a Python program to check if a given key already exists in a dictionary. If 
# key exists replace with another key/value pair.

d={'prasad':1,'omkar':2,'lokesh':3}
key=input("enter the key to checked:")
if key in d.keys():
    d.update({'harshad':4})
    d.pop(key)
    print(d)
else:
    print("key is not present:")

# Output
# enter the key to checked:omkar
# {'prasad': 1, 'lokesh': 3, 'harshad': 4}