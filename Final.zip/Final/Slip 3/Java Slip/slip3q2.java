// B) Define an abstract class Shape with abstract methods area () and volume (). Derive 
//  abstract class Shape into two classes Cone and Cylinder. Write a java Program 
//  to calculate area and volume of Cone and Cylinder.(Use Super Keyword.)

import java.util.*;

abstract class Shape
{
    float PI = 3.14F;
    Scanner s = new Scanner(System.in);
    abstract void area();
    abstract void volume();
}

class Cylinder extends Shape
{
    float a, r, h, v;

    void accept()
    {
        System.out.println("Enter radius and height of cylinder: ");
        r = s.nextFloat();        
        h = s.nextFloat();
    }
    void area()
    {
        a = (2*super.PI*r*h) + (2*super.PI*r*r);
        System.out.println("Area of Cylinder:"+a);
    }
    void volume()
    {
        v = super.PI*r*r*h;
        System.out.println("Volume of Cylinder:"+v);
    }
}

class Cone extends Shape
{
    float a, r, h, v;
    void accept()
    {
        System.out.println("Enter radius and height of cone: ");
        r = s.nextFloat();        
        h = s.nextFloat();
    }
    void area()
    {
        a = super.PI*r*(r+(float)Math.sqrt(h*h+r*r));
        System.out.println("Area of Cone:"+a);
    }
    void volume()
    {
        v = super.PI*r*r*(h/3);
        System.out.println("Volume of Cone:"+v);
    }
}

class slip3q2
{
    public static void main(String[] args) 
    {
        Cylinder c1 = new Cylinder();
        Cone c2 = new Cone();
        c1.accept();
        c2.accept();
        c1.area();
        c1.volume();
        c2.area();
        c2.volume();
    }
}

// Output
// Enter radius and height of cylinder:
// 5
// 5
// Enter radius and height of cone:
// 3
// 5
// Area of Cylinder:314.0
// Volume of Cylinder:392.5
// Area of Cone:83.18757
// Volume of Cone:47.1