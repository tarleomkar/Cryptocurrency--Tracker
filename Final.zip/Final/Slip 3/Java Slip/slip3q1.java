// A) Write a ‘java’ program to check whether given number is Armstrong or not.
//  (Use static keyword)

import java.util.Scanner;
import java.lang.Math;

public class slip3q1
{
    static boolean armstrong(int n)
    {
        int temp, digits = 0, last = 0, sum = 0;
        temp = n;

        while(temp>0)
        {
            temp = temp / 10;
            digits++;
        }
        temp = n;
        while(temp>0)
        {
            last = temp % 10;
            sum += (Math.pow(last,digits));
            temp = temp / 10;
        }
        if(n == sum)
            return true;
        else
            return false;
    }
    public static void main(String[] args) 
    {
        int num;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        num=sc.nextInt();
        if(armstrong(num))
        {
            System.out.print("Armstrong Number \n");
        }
        else
        {
            System.out.print("Not Armstrong Number \n");
        }
    }
}
// Output
// Enter a number: 153
// Armstrong Number