# A) Write a python script to create a class Rectangle with data member’s length, width 
# and methods area, perimeter which can compute the area and perimeter of rectangle.

class Rectangle:
    length = 0
    width = 0
    perimeter = 0
    area = 0

    def input(self):
        print("Enter length of rectangle : ",end ="")
        self.length = int(input())

        print("Enter length of rectangle : ",end ="")
        self.width = int(input())

    def area(self):
        self.area = self.length * self.width
        print("Area of rectangle is : " + str(self.area))

    def perimeter(self):
        self.perimeter = 2 * (self.length * self.width)
        print("perimeter of rectangle is : " + str(self.perimeter))

    def main(args):
        obj = Rectangle()
        obj.input()
        obj.area()
        obj.perimeter()

if __name__ == "__main__":
    Rectangle.main([])

# Output
# Enter length of rectangle : 5
# Enter length of rectangle : 2
# Area of rectangle is : 10
# perimeter of rectangle is : 20