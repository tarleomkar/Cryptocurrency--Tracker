import java.util.*;

public class Slip16b 
{
    static String[] str = new String[5];
    static Scanner sc = new Scanner(System.in);
    static ArrayList<String>list = new ArrayList<String>();

    public static void main(String args[])
    {
        for(int i = 0; i < str.length; i++)
        {
            System.out.print("Please insert Employe Name of Index of ["+i+"] : ");
            str[i] = sc.next();
            list.add(str[i]);
        }
        Collections.sort(list);
        System.out.println(list);
    }
}

// Output
// Please insert Employe Name of Index of [0] : Ram
// Please insert Employe Name of Index of [1] : Lakhan
// Please insert Employe Name of Index of [2] : Sita
// Please insert Employe Name of Index of [3] : Rass
// Please insert Employe Name of Index of [4] : Rasiya
// [Lakhan, Ram, Rasiya, Rass, Sita]