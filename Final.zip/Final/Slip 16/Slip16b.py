# B) Write Python GUI program to add items in listbox widget and to print and delete the 
# selected items from listbox on button click. Provide three separate buttons to add, print 
# and delete. 

import tkinter as tk

# create a window

window = tk.Tk()
window.title("List Widget")
window.geometry("500x500")

# add item function
def add_item():
    listbox.insert(tk.END,content.get())

# delete item function
def delete_item():
    listbox.delete(tk.ANCHOR)

# print item function
def print_item():
    for x in listbox.curselection():
        lbl.config(text = listbox.get(x))

# create a input box
content = tk.StringVar()
entry = tk.Entry(window,textvariable= content)
entry.pack()

# create an add button
button = tk.Button(window,text="Add Item",command= add_item)
button.pack()

# create an delete button
button_delete_selected = tk.Button(window,text="Delete Item",command= delete_item)
button_delete_selected.pack()

# create an print button
button_print_selected = tk.Button(window,text="print Item",command= print_item)
button_print_selected.pack()

# create a label
lbl = tk.Label(window,text="")
lbl.pack()

# create a listbox
listbox = tk.Listbox(window)
listbox.pack()
