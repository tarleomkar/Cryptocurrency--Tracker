# Write a python script to generate Fibonacci terms using generator function.


def fin(n):
    a, b = 0, 1

    for _ in range(n):
        yield a
        a, b = b, a + b


ln = int(input('Enter a number: '))
print(list(fin(ln)))

# Output
# Enter a number: 5
# [0, 1, 1, 2, 3]