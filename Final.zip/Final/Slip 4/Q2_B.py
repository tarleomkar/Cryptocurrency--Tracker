# B) Define a class Employee having members id, name, department, salary. Create a 
# subclass called manager with member bonus. Define methods accept and display in 
# both the classes. Create n objects of the manager class and display the details of the 
# manager having the maximum total salary (salary+bonus).

class Employee:
    def __init__(self, id, name, department, salary):
        self.id = id
        self.name = name
        self.department = department
        self.salary = salary

    def accept(self):
        self.id = int(input("Enter id: "))
        self.name = input("Enter name: ")
        self.department = input("Enter department: ")
        self.salary = int(input("Enter salary: "))

    def display(self):
        print("ID: ", self.id)
        print("Name: ", self.name)
        print("Department: ", self.department)
        print("Salary: ", self.salary)


class Manager(Employee):
    def __init__(self, id, name, department, salary, bonus):
        Employee.__init__(self, id, name, department, salary)
        self.bonus = bonus

    def accept(self):
        Employee.accept(self)
        self.bonus = int(input("Enter bonus: "))

    def display(self):
        Employee.display(self)
        print("Bonus: ", self.bonus)
        print("Total Salary: ", self.total_salary)
        print("\n")

    def total_salary(self):
        self.total_salary = self.salary + self.bonus
        return self.total_salary

manager = []
manager_total_salary = []

for i in range(int(input("Enter number of employees: "))):
    manager.append(Manager(0, "", "", 0, 0))
    print("\n")
    manager[i].accept()
    manager_total_salary.append(manager[i].total_salary())

print("Employee details: ")
for i in range(len(manager)):
    manager[i].display()

print(f"Higest salary: {max(manager_total_salary)}")

# Output
# Enter number of employees: 3


# Enter id: 1
# Enter name: rajat
# Enter department: cs
# Enter salary: 100000
# Enter bonus: 5000


# Enter id: 2
# Enter name: mahesh
# Enter department: design  
# Enter salary: 120000
# Enter bonus: 60000


# Enter id: 3
# Enter name: sam
# Enter department: editing
# Enter salary: 490000
# Enter bonus: 12334
# Employee details:
# ID:  1
# Name:  rajat
# Department:  cs
# Salary:  100000
# Bonus:  5000
# Total Salary:  105000


# ID:  2
# Name:  mahesh
# Department:  design
# Salary:  120000
# Bonus:  60000
# Total Salary:  180000


# ID:  3
# Name:  sam
# Department:  editing
# Salary:  490000
# Bonus:  12334
# Total Salary:  502334


# Higest salary: 502334