// B) Write a java Program to accept the details of 5 employees (Eno, Ename, Salary) and 
// display it onto the JTable.

import javax.swing.*;

public class Slip28b
{
    JFrame f;
    JTable j;
    Slip28b()
    {
        f = new JFrame();
        f.setTitle("Employee Details");
        String emp[][] = {
            {"101","Hitesh","50,000"},
            {"102","Deepak","50,00"},
            {"103","Parvesh","40,000"},
            {"104","Arman","10,000"},
            {"105","Arjun","50,000"},
            };
        String[] columnNames = {"Eno","Ename","Salary"};
        j = new JTable(emp,columnNames);
        j.setBounds(30,40,200,300);
        JScrollPane p = new JScrollPane(j);
        f.add(p);
        f.setSize(500,300);
        f.setVisible(true);
    }


public static void main(String[] args) 
{
    new Slip28b();    
}
}