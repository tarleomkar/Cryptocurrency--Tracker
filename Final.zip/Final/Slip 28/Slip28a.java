// A) Write a java program to count the number of integers from a given list. (Use 
//  Command line arguments)

import java.util.*;

public class Slip28a
{
    public static void main(String args[]) 
    {
        int count = 0;
        ArrayList<String> al = new ArrayList();
        for(int i = 0; i < args.length; i++)
        {
            al.add(args[i]);
        }
        for(int i = 0; i < al.size(); i++)
        {
            String ele = al.get(i);
            try
            {
                int j = Integer.parseInt(ele);
                count++;
            }catch(NumberFormatException e)
            {}
        }
        System.out.print(count + " Intgers are prsent in the list");
    }
}

// Output
// java Slip28a 2 3 4 5 6
// 5Intgers are prsent in the list