# B) Write a Python program to accept two lists and merge the two lists into list of tuple

lst1 = {2,5,7,8,9}
lst2 = {"Sanju",1,6,3}
tup1 = tuple(lst1)
tup2 = tuple(lst2)

result = tup1 + tup2
print(result)

# Ouput
# (2, 5, 7, 8, 9, 1, 'Sanju', 3, 6)