# A) Write a Python GUI program to create a list of Computer Science Courses using 
# Tkinter module (use Listbox).

import tkinter as tk

window = tk.Tk()

window.geometry("300x200")
lbl = tk.Label(window,text="Computer Science Course")
lbl.pack()

listbox = tk.Listbox(window)
listbox.pack()

listbox.insert(1,"C Language")
listbox.insert(2,"C++")
listbox.insert(3,"JAVA")
listbox.insert(4,"PYTHON")
listbox.insert(5,"JAVASCRIPT")

window.mainloop()