// B) Write a java program to design following Frame using Swing.

import java.awt.event.*;
import javax.swing.*;

public class Slip23b extends JFrame implements ActionListener
{
    public static void main(String[] args) 
    {
        new Slip23b();
    }
    public Slip23b()
    {
        this.setSize(600,500);
        this.setLocation(200,200);

        JMenuBar menuBar = new JMenuBar();
        JMenu filMenu = new JMenu("File");
        JMenu fileEdit = new JMenu("Edit");
        JMenu Search = new JMenu("Search");

        JMenuItem OpenItem = new JMenuItem("Open");
        JMenuItem SaveItem = new JMenuItem("Save");
        JMenuItem QuitItem = new JMenuItem("Quit");

        JMenuItem UndoItem = new JMenuItem("Undo");
        JMenuItem RedoItem = new JMenuItem("Redo");
        JMenuItem CutItem = new JMenuItem("Cut");
        JMenuItem CopyItem = new JMenuItem("Copy");
        JMenuItem PasteItem = new JMenuItem("Paste");

        // ImageIcon OpenIcon = new ImageIcon("change.png");

        filMenu.add(OpenItem);
        filMenu.add(SaveItem);
        filMenu.add(QuitItem);
        filMenu.add(UndoItem);
        filMenu.add(RedoItem);
        filMenu.add(CutItem);
        filMenu.add(CopyItem);
        filMenu.add(PasteItem);

        // OpenIcon.setIcon(OpenItem);

        menuBar.add(filMenu);
        menuBar.add(fileEdit);
        menuBar.add(Search);

        this.setJMenuBar(menuBar);
        this.setVisible(true);
    }
    public void actionPerformed(ActionEvent ae)
    {
        // Write your click event code
    }
}