// A) Write a java program to check whether given file is hidden or not. If not then 
//  display its path, otherwise display appropriate message.

import java.io.*;
import java.util.*;

public class Slip23a
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        try
        {
            System.out.print("Enter file name: ");
            String str = sc.nextLine();
            File file = new File(str);
            // Logic
            if(file.isHidden())
            {
                System.out.println("File is Hidden");
            }
            else
            {
                System.out.println("File Location : "+file.getAbsolutePath());
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

// Output
// Enter file name: Slip23a.java
// File Location : 