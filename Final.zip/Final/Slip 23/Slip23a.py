# A) Write a Python GUI program to create a label and change the label font style (font 
# name, bold, size) using tkinter module. 

import tkinter as tk

window = tk.Tk()
window.title("Slip 23 A")

lbl = tk.Label(window,text="Python",font=("Arial Bold",70))
lbl.pack()

window.mainloop()