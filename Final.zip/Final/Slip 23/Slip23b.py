# B) Create a class circles having members radius. Use operator overloading to add the 
# radius of two circle objects. Also display the area of circle.

import math

class Circles:
    def __init__(self,radius):
        self.__radius = radius

    def setRadius(self,radius):
        self.__radius = radius

    def getRadius(self):
        return self.__radius

    def area(self):
        return math.pi * self.__radius ** 2

    def __add__(self,second_circle):
        return Circles(self.__radius + second_circle.__radius)

c1 = Circles(5)
c2 = Circles(6)
c3 = c1 + c2

print("Addition of radius 1 + radius 2: ",c3.getRadius())
print("Area of Circle is: ",c3.area())

# Output
# Addition of radius 1 + radius 2:  11
# Area of Circle is:  380.132711084365 