// A) Write a Java program to calculate area of Circle, Triangle & Rectangle.(Use Method 
// Overloading)

import java.util.*;

class AreaCalculation
{
    // Area of circle
    double area(int r)
    {
        return 3.14 * r * r;
    }
    // Area of triangle
    float area(int b,float h)
    {
        return b * h / 2;
    }
    // Area of rectangle
    double area(float l,float rb)
    {
        return l + rb;
    }
}

class Slip18a
{
    public static void main(String[] args) 
    {
        int r, b, l, rb;
        float h;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter radius : ");
        r=sc.nextInt();
        System.out.println("Enter base : ");
        b=sc.nextInt();
        System.out.println("Enter height : ");
        h=sc.nextFloat();
        System.out.println("Enter length : ");
        l=sc.nextInt();
        System.out.println("Enter breadth : ");
        rb=sc.nextInt();

        AreaCalculation ac = new AreaCalculation();
        ac.area(r);
        System.out.println("Area of circle: "+ac.area(r));
        System.out.println("Area of triangle: "+ac.area(b,h));
        System.out.println("Area of rectangle: "+ac.area(l,rb));
    }
}

// Output
// Enter radius : 
// 5
// Enter base : 
// 5
// Enter height :
// 5
// Enter length :
// 5
// Enter breadth :
// 5
// Area of circle: 78.5
// Area of triangle: 12.5
// Area of rectangle: 12.5