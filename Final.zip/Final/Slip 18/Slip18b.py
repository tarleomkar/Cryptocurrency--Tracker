# B) Write a python script to define the class person having members name, address. 
# Create a subclass called Employee with members staffed salary. Create 'n' objects of the 
# Employee class and display all the details of the employee.

class Person:
    def __init__(self, name, address):
        self.name = name
        self.address = address

class Employee(Person):
    def __init__(self, name, address, salary):
        super().__init__(name, address)
        self.salary = salary

n = int(input("Enter the number of employees: "))

employees_list = []

for i in range(n):
    name = input("Enter the name: ")
    address = input("Enter the address: ")
    salary = int(input("Enter the salary: "))
    employees_list.append(Employee(name, address, salary))

print(f"\nEmployees List:")
for employee in employees_list:
    print(f"Name: {employee.name}")
    print(f"Address: {employee.address}")
    print(f"Salary: {employee.salary}")
    print("-" * 20)

# Output
# Enter the number of employees: 2
# Enter the name: Shiv
# Enter the address: Nsk
# Enter the salary: 123456
# Enter the name: Ram
# Enter the address: Pune
# Enter the salary: 7891011

# Employees List:
# Name: Shiv
# Address: Nsk
# Salary: 123456
# --------------------
# Name: Ram
# Address: Pune
# Salary: 7891011


# Another code
# class Person:
#     name = ""
#     address = ""

#     def accept1(self):
#         self.name = input("Enter Employee name: ")
#         self.address = input("Enter Employee address: ")

#     def display1(self):
#         print("Name : "+self.name)
#         print("address : "+self.address)

# class Employee(Person):
#     staffed_Salary = 0

#     def accept2(self):
#         self.staffed_Salary = float(input("Enter Salary: "))

#     def display2(self):
#         print("Salary : "+ str(self.staffed_Salary))

# n = int(input("Enter the number of employees: "))
# for i in range(n):
#     name = input("Enter the name: ")
#     address = input("Enter the address: ")
#     staffed_Salary = int(input("Enter the salary: "))
#     Employee(name, address, staffed_Salary)

# obj = Employee()
# obj.accept1()
# obj.accept2()
# obj.display1()
# obj.display2()
