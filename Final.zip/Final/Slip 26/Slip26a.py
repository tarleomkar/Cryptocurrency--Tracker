# A) Write an anonymous function to find area of square and rectangle. 

area_of_square = lambda length : length * length
area_of_rect = lambda length,width : length * width

l = int(input("Enter Length to Calculate area of square: "))
print("Area of Square is: ",area_of_square(l))
l = int(input("Enter Length to Calculate area of Rectangle: "))
w = int(input("Enter width to Calculate area of Rectangle: "))
print("Area of Rectnagle is: ",area_of_rect(l,w))

# Output
# Enter Length to Calculate area of square:
#  4
# Area of Square is:  16
# Enter Length to Calculate area of Rectangle: 4
# Enter width to Calculate area of Rectangle: 4
# Area of Rectnagle is:  16