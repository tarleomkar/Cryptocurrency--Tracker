# B) Write Python GUI program which accepts a sentence from the user and alters it 
# when a button is pressed. Every space should be replaced by *, case of all alphabets 
# should be reversed, digits are replaced by?. 

import tkinter 
from tkinter import *

def change(): 
	sentence = e1.get() 
	result = '' 
	for i in sentence: 
		if i.isalpha(): 
			result += i.swapcase() 
		elif i.isdigit(): 
			result += '?'
		elif i == ' ': 
			result += '*'
		else: 
			result += i
			
	l1.configure(text = result) 
	
root = Tk() 
root.geometry("400x200") 

e1 = Entry(root) 
e1.pack() 

b1 = Button(root, text = "Change", command = change) 
b1.pack() 

l1 = Label(root) 
l1.pack() 

root.mainloop()