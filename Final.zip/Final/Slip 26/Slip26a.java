// A) Write a java program to display ASCII values of the characters from a file.

import java.util.*;
import java.io.*;

class Slip26a
{
    public static void main(String[] args) throws IOException
    {
        char ch;
        FileReader fr = new FileReader("demo.txt");
        int c;
        while((c = fr.read()) != -1)
        {
            ch = (char)c;
            if(Character.isDigit(ch) == false && (Character.isSpaceChar(c) == false))
            {
                System.out.println("ASCII "+ch+" : "+c);
            }
        }
        fr.close();

    }
}

// Output
// ASCII j : 106
// ASCII a : 97
// ASCII v : 118
// ASCII a : 97